package org.usfirst.frc.team6560.robot.commands;

public abstract class ControlMotor {

}
